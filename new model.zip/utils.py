import joblib
import numpy as np
import os
import pandas as pd
from dotenv import load_dotenv
import google.generativeai as genai

load_dotenv()

MODEL_PATH = "app/disease_model.pkl"
METRICS_PATH = "app/model_metrics.pkl"


def load_model():
    return joblib.load(MODEL_PATH)


def load_metrics():
    return joblib.load(METRICS_PATH)


def predict_top3(symptoms_selected):
    model_bundle = load_model()
    clf = model_bundle["model"]
    le = model_bundle["encoder"]
    all_symptoms = model_bundle["symptoms"]
    # Encode input as one-hot
    input_features = np.zeros(len(all_symptoms))
    for idx, sym in enumerate(all_symptoms):
        if sym in symptoms_selected:
            input_features[idx] = 1
    probs = clf.predict_proba([input_features])[0]
    top_idxs = np.argsort(probs)[::-1][:3]
    preds = [(le.inverse_transform([i])[0], probs[i]) for i in top_idxs]
    return preds, input_features


def explain_with_gemini(symptoms_selected, preds, confusion_matrix, report_df):
    API_KEY = os.getenv("GOOGLE_API_KEY")
    if not API_KEY:
        return "No Gemini API key set. Please add GOOGLE_API_KEY to your .env file."
    genai.configure(api_key=API_KEY)
    model = genai.GenerativeModel("gemini-2.0-flash")
    pred_str = ", ".join([f"{d} ({s*100:.1f}%)" for d, s in preds])
    cm_str = confusion_matrix.to_string()
    class_metrics_str = report_df.to_string()
    prompt = f"""
Given the symptoms: {', '.join(symptoms_selected)}
The model predicted these diseases (with probabilities): {pred_str}.

Here is the model's confusion matrix:
{cm_str}

And per-class metrics (precision, recall, F1-score):
{class_metrics_str}

Explain why the top prediction was made, referencing both the symptom evidence and the model's performance on similar diseases (e.g., is the model good or poor at distinguishing between them?).

Please provide a detailed explanation of the reasoning behind the top prediction.
DO NOT MENTION THE MODEL'S ACCURACY OR OVERALL PERFORMANCE.
DO NOT MENTION CONFUSION MATRIX OR CLASS METRICS. DO NOT ANALYZE THE MODEL'S PERFORMANCE WITH RESPECT TO THE DATA.

JUST RETURN THE REASONING BEHIND THE TOP PREDICTION relating the feature evidence or feature importance to the prediction.
"""
    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        return f"Gemini API call failed: {e}"
